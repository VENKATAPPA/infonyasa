﻿using System;

namespace CloudCaptions
{
	public enum Error
	{
		Ignore,
		Retry,
		Success
	}
}

